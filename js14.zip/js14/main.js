/**
 * Created by apple on 20.05.16.
 */

// Директива use strict;
"use strict";

// Создаем объект
var data = {
    title: {
        value: "Тест по Второй мировой войне"
    },
    list_question: [
        {
            question: "Когда началась Вторая мировая война",
            options: [
                "1940",
                "1941",
                "1939"
            ],
            answer: "1939"
        },
        {
            question: "Какая битва повлияла на исход всей Второй мировой войны?",
            options: [
                "Битва в Арденском лесу",
                "Сталинградская битва",
                "Битва у Аль-Аламейна"
            ],
            answer: "Сталинградская битва"
        },
        {
            question: "Кто возглавлял Африканскую компанию со стороны Германии?",
            options: [
                "Гудериан",
                "Роммель",
                "Кох"
            ],
            answer: "Роммель"
        }
    ]
};

// Записываем объект в localStorage
localStorage.setItem('test', JSON.stringify(data));
console.log(localStorage.getItem('test'));

// Берем объект из localStorage
var returnData = JSON.parse(localStorage.getItem('test'));
console.log(returnData);

// Рендеринг с помощью LoDash шаблонизатора
$(function () {
    var html = _.template($('#testId').html());

    var content = html(returnData);
    $('body').append(content);

    $('.check').click(function() {
        $("input[type='radio']:checked").each(function() {
            var idRadio = $(this).attr("id");
            var result = $("label[for='"+idRadio+"'] span").text();
            alert(result); // result и есть содержимое span
        });
    });

});

// Берем данные из радиобаттонов

var answers = [];

//function clickBox (ch, val) {
//    var box = document.getElementById(ch);
//    console.log( val );
//    answers.push(val);
//}
//onclick="clickBox('ch<%=n+''+i%>', '<%=variant%>')

function func(e){
    console.log( e.target );
}






