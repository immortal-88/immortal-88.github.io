//



function myFunction() {
    var e = document.getElementById('myDropdown');
    if (e.style.display == 'none' || e.style.display == '') {
        e.style.display = 'block';
    } else {
        e.style.display = 'none';
    }
}


$(document).ready(function() {
    $(".owl-carousel").owlCarousel({
        items: 1,
        autoplay: false,
        loop: true,
        animateOut: 'fadeOut'
    });
});

$(document).ready(function() {

    $('.activeContent').show();

    function close_accordion_section() {
        $('.accordion .accordion-section-title').removeClass('active');
        $('.accordion .accordion-section-content').slideUp(300).removeClass('open');
    }

    $('.accordion-section-title').click(function(e) {
        // Grab current anchor value
        var currentAttrValue = $(this).attr('href');

        if ($(e.target).is('.active')) {
            close_accordion_section();
        } else {
            close_accordion_section();

            // Add active class to section title
            $(this).addClass('active');
            // Open up the hidden content panel
            $('.accordion ' + currentAttrValue).stop().slideDown(300).addClass('open');
        }

        e.preventDefault();
    });
});

$('.btn-group .btn').on('click', function() {

    var self = $(this);

    if (self.find(':checkbox').length > 0) {
        //alert('checkbox clicked');
        if (self.hasClass('selectit')) {
            self.removeClass('selectit');
            self.addClass('btn-default');
        } else {
            self.addClass('selectit');
            self.removeClass('btn-default');
        }
        return;
    }

    if (self.find(':radio').length > 0) {
        //alert('radiobutton clicked');
        // CHANGE SELECTED ITEM TO GREEN   
        self.siblings("label").addBack().each(function(index, value) {
            $(this).removeClass("selectit");
            $(this).addClass("btn-default");
        });
        //alert($(this).text());
        self.removeClass("btn-default");
        self.addClass("selectit");
        return;
    }
});

$('.btn-group .btn').on('click', function() {
    if ($(this).hasClass("free")) {
        $('.tr').addClass('hidden');
    } else {
        $('.tr').removeClass('hidden');
    }
});

$(document).ready(function() {
    $("input[name='demo3']").TouchSpin({
        initval: 1
    });
});

$(function() {
    $(document).ready(function() {

        $('#count-words').on('change keyup keydown', function() {

            var $_count = ($.trim($(this).val()));
            var replacer = " ";
            var test = $_count.replace(/\s[a-яА-ЯA-Za-z0-9]{1,3}/g, replacer);
            var test1 = test.replace(/\s+/g, " ");
            var $_out = test1.split(" ").length-1; // Подсчет слов 

            $('#word-count').find('#counted').text($_out); // Вывод подсчета
        });
    });
});