/**
 * Created by apple on 14.04.16.
 */
$(document).ready(function() {

    /* Apply fancybox to multiple items */

    //$(".fancybox").fancybox({
    //    'transitionIn'	:	'elastic',
    //    'transitionOut'	:	'elastic',
    //    'speedIn'		:	600,
    //    'speedOut'		:	200,
    //    'overlayShow'	:	false
    //});

    $(".fancybox").fancybox();

});